<?php
$str_button      = 'scriptcase9_BlueBerry';
$str_chart_theme = '';
$str_grid_header_bg = "";
$str_google_fonts = "";
$pagina_schemamenu = 'scriptcase/default';
$index_class_pos = '';
$index_class_neg = '';
$index_class_neu = '';
$breadcrumbline_separator = 'scriptcase__NM__ico__NM__breadcrumb_black.png';
$expand_icon = 'scriptcase__NM__icon_expand.png';
$collapse_icon = 'scriptcase__NM__icon_expand.png';
?>