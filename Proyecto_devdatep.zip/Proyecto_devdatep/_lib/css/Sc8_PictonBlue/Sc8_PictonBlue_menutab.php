<?php
$str_button      = '';
$str_chart_theme = '';
$str_grid_header_bg = "";
$str_google_fonts = "";
$index_class_pos = '';
$index_class_neg = '';
$index_class_neu = '';
$css_menutab_active_close_icon = 'scriptcase__NM__ico__NM__refinedsearch_close.png';
$css_menutab_inactive_close_icon = 'scriptcase__NM__ico__NM__refinedsearch_close_w.png';
?>