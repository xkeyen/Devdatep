<?php 
  include_once('../menu_seg/index.php'); 
?> 
